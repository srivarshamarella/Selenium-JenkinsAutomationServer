package com.SpringCloudDemo.Miracle_Automation_Framework;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Test_Scenarios {
	Reusable_scenarios call_scenarios;
	POM_Reusable_Functions obj;
	@BeforeTest
	public void connect_driver_class() throws IOException{
		call_scenarios = new Reusable_scenarios();
		call_scenarios.connect_chrome_driver();
		obj=call_scenarios.call_POM_Reusable_Functions();
	}
	
	@Test(priority = 0)
	private void user_login_scenario() {
		call_scenarios.user_login(obj);
	}
	@Test(priority = 1)
	private void searching_keyword() {
		obj.click_Search_tab();
		call_scenarios.searching(obj);
	}
	@Test(priority = 2)
	private void user_sign_out() {
		call_scenarios.user_signout(obj);
	}
}
