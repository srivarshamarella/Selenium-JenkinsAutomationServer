package com.SpringCloudDemo.Miracle_Automation_Framework;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class POM_Reusable_Functions {

	WebDriver driver;
	// Username field
	By userName;
    //Password field
	By password ;
	//Click on Submit login button
	By login;
	//click on the user logo button
	By user_logo;
	//click on the logout button 
	By user_logout; 
	//find employee search button on the left
	By employee_search;
	//find  the employee search bar
	By employee_search_bar;
	//find the employee search button
	By employee_search_button;
	//Search string 
	String search_string= null;
	public POM_Reusable_Functions(WebDriver driver, Properties load_configuration_details) {

		this.driver = driver;
		// Username field
		this.userName = By.xpath(load_configuration_details.getProperty("username_xpath"));
	    //Password field
		this.password = By.xpath(load_configuration_details.getProperty("password_xpath"));
		//Click on Submit login button
		this.login = By.xpath(load_configuration_details.getProperty("login_xpath"));
		//click on the user logo button
		this.user_logo = By.xpath(load_configuration_details.getProperty("user_logo_xpath"));
		//click on the logout button 
		this.user_logout = By.xpath(load_configuration_details.getProperty("user_logout_button"));
		//find employee search button on the left
		this.employee_search= By.xpath(load_configuration_details.getProperty("employee_search_tab_xpath"));
		//find  the employee search bar
		this.employee_search_bar= By.xpath(load_configuration_details.getProperty("employee_search_bar_xpath"));
		//find the employee search button
		this.employee_search_button= By.xpath(load_configuration_details.getProperty("employee_search_button_xpath"));
		this.search_string= load_configuration_details.getProperty("search_string");
		
	}
	// Set user name in textbox

	public void setUserName(String strUserName) {

		this.driver.findElement(userName).sendKeys(strUserName);

	}

	// Set password in password textbox

	public void setPassword(String strPassword) {

		this.driver.findElement(password).sendKeys(strPassword);

	}

	// Click on login button

	public void clickLogin() {

		this.driver.findElement(login).click();

	}

	// Get the title of Login Page

	public String getLoginTitle() {

		return this.driver.getTitle();

	}
	//Get the employee search tab on the left 
	public void click_Search_tab() {
		this.driver.findElement(employee_search).click();
	}
	//Get the search bar 
	public void click_Search_bar() {
		this.driver.findElement(employee_search_bar).click();
		this.driver.findElement(employee_search_bar).sendKeys(search_string);
	}
	//Get the search bar 
		public void click_Search_button() {
			this.driver.findElement(employee_search_button).click();
		}
	//Get the user logo after sign in on the top right corner of the page
	public void click_logo() {
		this.driver.findElement(user_logo).click();
	}
	//Get the user logout button after sign in on the top right corner of the page
		public void click_logout() {
			this.driver.findElement(user_logout).click();
		}


	public void implicit_wait(int time_seconds) {
		this.driver.manage().timeouts().implicitlyWait(time_seconds, TimeUnit.SECONDS);
	}

	public void navigate_back() {

		this.driver.navigate().back();
	}
	
	public void verify_page_title(String Expectedtitle) {
		// TODO Auto-generated method stub
		String Actualtitle = this.getLoginTitle();
		System.out.println("Before Assetion " + Expectedtitle + Actualtitle);
		//it will compare actual title and expected title
		Assert.assertEquals(Actualtitle, Expectedtitle);
		//print out the result
		System.out.println("After Assertion " + Expectedtitle + Actualtitle + " Title matched ");
		 
	}
	public void close_driver(WebDriver driver){
		driver.close();
	}

}