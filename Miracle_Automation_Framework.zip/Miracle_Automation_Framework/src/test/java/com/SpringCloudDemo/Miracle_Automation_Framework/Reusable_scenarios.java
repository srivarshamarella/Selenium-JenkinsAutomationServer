package com.SpringCloudDemo.Miracle_Automation_Framework;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Reusable_scenarios {
	WebDriver driver = null;
	POM_Reusable_Functions objLogin;
	Properties load_configuration_details;
	protected WebDriver connect_chrome_driver() throws IOException {	
		load_configuration_details = new Properties();
		FileInputStream file = new FileInputStream(System.getProperty("user.dir") + "\\application.properties");
		load_configuration_details.load(file);
		WebDriverManager.chromedriver().driverVersion("83.0.4103.39").setup();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("start-maximized"); 
		options.addArguments("enable-automation"); 
		options.addArguments("--no-sandbox"); 
		options.addArguments("--disable-infobars");
		options.addArguments("--disable-dev-shm-usage");
		options.addArguments("--disable-browser-side-navigation"); 
		options.addArguments("--disable-gpu"); 
		driver = new ChromeDriver(options); 
		driver.manage().window().maximize();
		driver.get(load_configuration_details.getProperty("Url"));
		return driver; 
	}
	public POM_Reusable_Functions call_POM_Reusable_Functions() {
		// Create Login Page object
		objLogin = new POM_Reusable_Functions(driver,load_configuration_details);
		return objLogin;
	}
	public void user_login(POM_Reusable_Functions objLogin){
		// Verify login page title
				objLogin.verify_page_title(load_configuration_details.getProperty("verify_title"));
				objLogin.implicit_wait(50);
				// Fill user name
				objLogin.setUserName(load_configuration_details.getProperty("UserName"));
				objLogin.implicit_wait(50);
				// Fill password
				objLogin.setPassword(load_configuration_details.getProperty("password"));
				// Click Login button
				objLogin.clickLogin();
				objLogin.implicit_wait(50);
				//objLogin.close_driver(driver);
	}
	
	public void searching(POM_Reusable_Functions objLogin){
		//objLogin.click_Search_tab();
				//objLogin.implicit_wait(500);
				objLogin.click_Search_bar();
				objLogin.implicit_wait(500);
				objLogin.click_Search_button();
				objLogin.implicit_wait(500);
	}
	public void user_signout(POM_Reusable_Functions objLogin){
		objLogin.click_logo();
		objLogin.implicit_wait(50);
		objLogin.click_logout();
		objLogin.close_driver(driver);
	}
}
